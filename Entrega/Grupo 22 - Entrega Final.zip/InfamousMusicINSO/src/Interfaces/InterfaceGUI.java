package Interfaces;

public interface InterfaceGUI {
	
	public void arrancar();

	public void resetear();
}
