package dataObjetAccess;

public class SeguridadDAO {

}
